Within this directory the great scott gadgets library should be download (available at https://github.com/greatscottgadgets/gsg-kicad-lib)

